#!/usr/bin/env python3
"""
false_sharing.py -- Phase 4, Experiment A analogue

Counts how many i in [1,N] have collatz_steps(i) > 100.

Run:  python3 false_sharing.py <num_workers> <variant>
  variant = naive      -> per-iteration write into a tightly-packed shared
                           array (mirrors C's hit_count[tid]++ inside the
                           hot loop -> real cross-core cache-line thrashing)
  variant = padded     -> each worker's counter pushed onto its own stride
                           (cache line) -> mitigated
  variant = reduction  -> fully private local counters, combined only once
                           at the end in the parent process -> mitigated

NOTE: Prototype only. Graded deliverable is false_sharing.c (gcc -fopenmp).
"""

import sys
import ctypes
import time
import multiprocessing as mp

# Student ID 230109011 -> last 4 digits = 9011
N = 10_000_000 + 9011 * 1000   # = 19,011,000
THRESHOLD = 100

_SHARED = None  # populated per-worker-process via Pool initializer


def collatz_steps(n: int) -> int:
    steps = 0
    while n > 1:
        if n & 1 == 0:
            n >>= 1
        else:
            n = 3 * n + 1
        steps += 1
    return steps


def make_chunks(n, k):
    chunk = n // k
    chunks = []
    start = 1
    for w in range(k):
        end = n if w == k - 1 else start + chunk - 1
        chunks.append((start, end))
        start = end + 1
    return chunks


def _init_shared(shared_array):
    global _SHARED
    _SHARED = shared_array


def worker_naive(args):
    lo, hi, tid = args
    arr = _SHARED
    for i in range(lo, hi + 1):
        if collatz_steps(i) > THRESHOLD:
            arr[tid] += 1  # per-iteration write -> false sharing
    return None


def worker_padded(args):
    lo, hi, tid, stride = args
    arr = _SHARED
    idx = tid * stride
    for i in range(lo, hi + 1):
        if collatz_steps(i) > THRESHOLD:
            arr[idx] += 1  # own cache line -> no false sharing
    return None


def worker_reduction(args):
    lo, hi = args
    local = 0
    for i in range(lo, hi + 1):
        if collatz_steps(i) > THRESHOLD:
            local += 1
    return local  # combined once, in the parent, after the loop


def run_naive(k, chunks):
    shared = mp.Array(ctypes.c_long, k)
    args = [(lo, hi, idx) for idx, (lo, hi) in enumerate(chunks)]
    t0 = time.perf_counter()
    with mp.Pool(processes=k, initializer=_init_shared, initargs=(shared,)) as pool:
        pool.map(worker_naive, args)
    t1 = time.perf_counter()
    return sum(shared[:]), t1 - t0


def run_padded(k, chunks):
    stride = 16  # 16 * 8 bytes (c_long) = 128 bytes, safely > one 64B cache line
    shared = mp.Array(ctypes.c_long, k * stride)
    args = [(lo, hi, idx, stride) for idx, (lo, hi) in enumerate(chunks)]
    t0 = time.perf_counter()
    with mp.Pool(processes=k, initializer=_init_shared, initargs=(shared,)) as pool:
        pool.map(worker_padded, args)
    t1 = time.perf_counter()
    total = sum(shared[i * stride] for i in range(k))
    return total, t1 - t0


def run_reduction(k, chunks):
    t0 = time.perf_counter()
    with mp.Pool(processes=k) as pool:
        results = pool.map(worker_reduction, chunks)
    t1 = time.perf_counter()
    return sum(results), t1 - t0


def main():
    k = int(sys.argv[1]) if len(sys.argv) > 1 else mp.cpu_count()
    variant = sys.argv[2] if len(sys.argv) > 2 else "naive"

    chunks = make_chunks(N, k)

    if variant == "naive":
        total_hits, elapsed = run_naive(k, chunks)
    elif variant == "padded":
        total_hits, elapsed = run_padded(k, chunks)
    elif variant == "reduction":
        total_hits, elapsed = run_reduction(k, chunks)
    else:
        print(f"Unknown variant '{variant}'. Use naive|reduction|padded", file=sys.stderr)
        sys.exit(1)

    print(f"Variant          = {variant}")
    print(f"Workers (k)      = {k}")
    print(f"Total hits(>100) = {total_hits}")
    print(f"Elapsed time (s) = {elapsed:.6f}")
    print(f"Throughput (iter/sec) = {N / elapsed:.0f}")


if __name__ == "__main__":
    main()
