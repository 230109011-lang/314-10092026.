#!/usr/bin/env python3
"""
collatz_par.py -- Multi-process scaling (Phase 3 analogue)

Run:  python3 collatz_par.py <num_workers>
  e.g. python3 collatz_par.py 4

Uses multiprocessing.Pool (separate OS processes, separate memory),
NOT threading -- CPython's GIL serializes threads on CPU-bound work,
so `threading` would give zero speedup and misrepresent Amdahl's Law.
multiprocessing is the closest honest analogue to OpenMP's execution
units, at the cost of higher spawn/IPC overhead than real threads.

NOTE: Prototype only. Graded deliverable is collatz_omp.c (gcc -fopenmp).
"""

import sys
import time
import multiprocessing as mp

# Student ID 230109011 -> last 4 digits = 9011
N = 10_000_000 + 9011 * 1000   # = 19,011,000
MOD = 1_000_000_007


def collatz_steps(n: int) -> int:
    steps = 0
    while n > 1:
        if n & 1 == 0:
            n >>= 1
        else:
            n = 3 * n + 1
        steps += 1
    return steps


def make_chunks(n, k):
    """Static, roughly-equal contiguous partitioning (like schedule(static))."""
    chunk = n // k
    chunks = []
    start = 1
    for w in range(k):
        end = n if w == k - 1 else start + chunk - 1
        chunks.append((start, end))
        start = end + 1
    return chunks


def worker(args):
    lo, hi = args
    local_max = 0
    local_max_i = 0
    local_checksum = 0
    for i in range(lo, hi + 1):
        s = collatz_steps(i)
        local_checksum = (local_checksum + s) % MOD
        if s > local_max:
            local_max, local_max_i = s, i
    return local_max, local_max_i, local_checksum


def main():
    k = int(sys.argv[1]) if len(sys.argv) > 1 else mp.cpu_count()
    chunks = make_chunks(N, k)

    t0 = time.perf_counter()
    with mp.Pool(processes=k) as pool:
        results = pool.map(worker, chunks)
    t1 = time.perf_counter()

    global_max, global_max_i, checksum_total = 0, 0, 0
    for local_max, local_max_i, local_checksum in results:
        checksum_total = (checksum_total + local_checksum) % MOD
        if local_max > global_max:
            global_max, global_max_i = local_max, local_max_i

    print(f"Workers (k)      = {k}")
    print(f"N                = {N}")
    print(f"Max steps        = {global_max} (at i = {global_max_i})")
    print(f"Checksum (mod 1e9+7) = {checksum_total}")
    print(f"Elapsed time (s) = {t1 - t0:.6f}")


if __name__ == "__main__":
    main()
