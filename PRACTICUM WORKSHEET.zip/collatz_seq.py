#!/usr/bin/env python3
"""
collatz_seq.py -- Sequential baseline (Phase 2 analogue)

Run:  python3 collatz_seq.py

NOTE: This Python script is a sanity-check / prototype only.
The worksheet's grading rubric requires the C/OpenMP submission
(collatz_seq.c, compiled with `gcc -O2 -fopenmp`). Use this file
to understand the algorithm and expected numbers, not as your
graded deliverable.
"""

import time

# Student ID 230109011 -> last 4 digits = 9011
N = 10_000_000 + 9011 * 1000   # = 19,011,000
MOD = 1_000_000_007


def collatz_steps(n: int) -> int:
    steps = 0
    while n > 1:
        if n & 1 == 0:
            n >>= 1
        else:
            n = 3 * n + 1
        steps += 1
    return steps


def main():
    t0 = time.perf_counter()

    max_steps = 0
    max_i = 0
    checksum = 0

    for i in range(1, N + 1):
        s = collatz_steps(i)
        checksum = (checksum + s) % MOD
        if s > max_steps:
            max_steps, max_i = s, i

    t1 = time.perf_counter()

    print(f"N                = {N}")
    print(f"Max steps        = {max_steps} (at i = {max_i})")
    print(f"Checksum (mod 1e9+7) = {checksum}")
    print(f"Elapsed time (s) = {t1 - t0:.6f}")


if __name__ == "__main__":
    main()
