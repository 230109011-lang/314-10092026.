#!/usr/bin/env python3
"""
scheduling.py -- Phase 4, Experiment B analogue: loop scheduling comparison

Run:  python3 scheduling.py <num_workers> <mode> [chunksize]
  mode = static    -> pre-split into k equal contiguous chunks
                       (analogue of OpenMP schedule(static))
  mode = dynamic   -> Pool.map(..., chunksize=N) work-queue distribution
                       (analogue of OpenMP schedule(dynamic, chunk))

Examples:
  python3 scheduling.py 4 static
  python3 scheduling.py 4 dynamic 100
  python3 scheduling.py 4 dynamic 10000

NOTE: Prototype only. Graded deliverable is scheduling.c (gcc -fopenmp),
which also covers schedule(static,1000) and schedule(guided) -- OpenMP-
specific clauses with no clean multiprocessing.Pool equivalent.
"""

import sys
import time
import multiprocessing as mp

# Student ID 230109011 -> last 4 digits = 9011
N = 10_000_000 + 9011 * 1000   # = 19,011,000
MOD = 1_000_000_007


def collatz_steps(n: int) -> int:
    steps = 0
    while n > 1:
        if n & 1 == 0:
            n >>= 1
        else:
            n = 3 * n + 1
        steps += 1
    return steps


def make_chunks(n, k):
    chunk = n // k
    chunks = []
    start = 1
    for w in range(k):
        end = n if w == k - 1 else start + chunk - 1
        chunks.append((start, end))
        start = end + 1
    return chunks


def worker_sum_range(args):
    lo, hi = args
    s = 0
    for i in range(lo, hi + 1):
        s = (s + collatz_steps(i)) % MOD
    return s


def run_static(k):
    chunks = make_chunks(N, k)
    t0 = time.perf_counter()
    with mp.Pool(processes=k) as pool:
        results = pool.map(worker_sum_range, chunks)
    t1 = time.perf_counter()
    return sum(results) % MOD, t1 - t0


def run_dynamic(k, chunksize):
    t0 = time.perf_counter()
    with mp.Pool(processes=k) as pool:
        # Pool.map's chunksize is the closest analogue to OpenMP's
        # schedule(dynamic, chunk) work-queue behaviour: small chunksize
        # -> fine-grained, more balanced but more scheduling overhead.
        results = pool.map(collatz_steps, range(1, N + 1), chunksize=chunksize)
    t1 = time.perf_counter()
    total = sum(results) % MOD
    return total, t1 - t0


def main():
    k = int(sys.argv[1]) if len(sys.argv) > 1 else mp.cpu_count()
    mode = sys.argv[2] if len(sys.argv) > 2 else "static"
    chunksize = int(sys.argv[3]) if len(sys.argv) > 3 else 100

    if mode == "static":
        total, elapsed = run_static(k)
        cs_label = "N / k (equal contiguous chunks)"
    elif mode == "dynamic":
        total, elapsed = run_dynamic(k, chunksize)
        cs_label = str(chunksize)
    else:
        print(f"Unknown mode '{mode}'. Use static|dynamic", file=sys.stderr)
        sys.exit(1)

    print(f"Mode             = {mode}")
    print(f"Chunksize        = {cs_label}")
    print(f"Workers (k)      = {k}")
    print(f"Total steps sum  = {total}")
    print(f"Elapsed time (s) = {elapsed:.6f}")


if __name__ == "__main__":
    main()
