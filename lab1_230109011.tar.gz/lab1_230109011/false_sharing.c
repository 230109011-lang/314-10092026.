/*
 * false_sharing.c -- Phase 4, Experiment A
 *
 * Counts how many i in [1,N] have collatz_steps(i) > 100.
 *
 * Compile:  gcc -O2 -fopenmp false_sharing.c -o false_sharing
 * Run:      ./false_sharing <num_threads> <variant>
 *   variant = naive      -> triggers false sharing (hit_count[tid]++)
 *   variant = reduction  -> mitigated via OpenMP reduction
 *   variant = padded     -> mitigated via cache-line-padded struct
 *
 * >>> EDIT N to match your own Student-ID-derived workload <<<
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <omp.h>

#define N 19011000ULL   /* Student ID 230109011 -> last4=9011 */
#define MAX_THREADS 64
#define THRESHOLD 100

typedef struct {
    int count;
    char pad[60];   /* pad struct out to 64 bytes -> own cache line */
} Padded;

static inline uint32_t collatz_steps(uint64_t n) {
    uint32_t steps = 0;
    while (n > 1) {
        if ((n & 1) == 0) n >>= 1;
        else n = 3 * n + 1;
        steps++;
    }
    return steps;
}

int main(int argc, char **argv) {
    int k = (argc > 1) ? atoi(argv[1]) : omp_get_max_threads();
    const char *variant = (argc > 2) ? argv[2] : "naive";
    omp_set_num_threads(k);

    long total_hits = 0;
    double t0, t1;

    if (strcmp(variant, "naive") == 0) {
        /* Implementation 1: deliberately triggers false sharing */
        static int hit_count[MAX_THREADS];
        memset(hit_count, 0, sizeof(hit_count));

        t0 = omp_get_wtime();
        #pragma omp parallel for schedule(static)
        for (uint64_t i = 1; i <= N; i++) {
            if (collatz_steps(i) > THRESHOLD) {
                hit_count[omp_get_thread_num()]++;
            }
        }
        t1 = omp_get_wtime();

        for (int t = 0; t < k; t++) total_hits += hit_count[t];

    } else if (strcmp(variant, "reduction") == 0) {
        t0 = omp_get_wtime();
        #pragma omp parallel for schedule(static) reduction(+:total_hits)
        for (uint64_t i = 1; i <= N; i++) {
            if (collatz_steps(i) > THRESHOLD) total_hits++;
        }
        t1 = omp_get_wtime();

    } else if (strcmp(variant, "padded") == 0) {
        static Padded hit_count[MAX_THREADS];
        memset(hit_count, 0, sizeof(hit_count));

        t0 = omp_get_wtime();
        #pragma omp parallel for schedule(static)
        for (uint64_t i = 1; i <= N; i++) {
            if (collatz_steps(i) > THRESHOLD) {
                hit_count[omp_get_thread_num()].count++;
            }
        }
        t1 = omp_get_wtime();

        for (int t = 0; t < k; t++) total_hits += hit_count[t].count;

    } else {
        fprintf(stderr, "Unknown variant '%s'. Use naive|reduction|padded\n", variant);
        return 1;
    }

    double elapsed = t1 - t0;
    printf("Variant          = %s\n", variant);
    printf("Threads (k)      = %d\n", k);
    printf("Total hits(>100) = %ld\n", total_hits);
    printf("Elapsed time (s) = %.6f\n", elapsed);
    printf("Throughput (iter/sec) = %.0f\n", (double)N / elapsed);

    return 0;
}
