/*
 * scheduling.c -- Phase 4, Experiment B: loop scheduling comparison
 *
 * Compile:  gcc -O2 -fopenmp scheduling.c -o scheduling
 * Run:      ./scheduling <num_threads> <mode>
 *   mode = static        (schedule(static))
 *   mode = static1000    (schedule(static,1000))
 *   mode = dynamic100    (schedule(dynamic,100))
 *   mode = dynamic10000  (schedule(dynamic,10000))
 *   mode = guided        (schedule(guided))
 *
 * >>> EDIT N to match your own Student-ID-derived workload <<<
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <omp.h>

#define N 19011000ULL   /* Student ID 230109011 -> last4=9011 */

static inline uint32_t collatz_steps(uint64_t n) {
    uint32_t steps = 0;
    while (n > 1) {
        if ((n & 1) == 0) n >>= 1;
        else n = 3 * n + 1;
        steps++;
    }
    return steps;
}

int main(int argc, char **argv) {
    int k = (argc > 1) ? atoi(argv[1]) : omp_get_max_threads();
    const char *mode = (argc > 2) ? argv[2] : "static";
    omp_set_num_threads(k);

    uint64_t total_steps = 0;
    double t0 = omp_get_wtime();

    if (strcmp(mode, "static") == 0) {
        #pragma omp parallel for schedule(static) reduction(+:total_steps)
        for (uint64_t i = 1; i <= N; i++) total_steps += collatz_steps(i);

    } else if (strcmp(mode, "static1000") == 0) {
        #pragma omp parallel for schedule(static, 1000) reduction(+:total_steps)
        for (uint64_t i = 1; i <= N; i++) total_steps += collatz_steps(i);

    } else if (strcmp(mode, "dynamic100") == 0) {
        #pragma omp parallel for schedule(dynamic, 100) reduction(+:total_steps)
        for (uint64_t i = 1; i <= N; i++) total_steps += collatz_steps(i);

    } else if (strcmp(mode, "dynamic10000") == 0) {
        #pragma omp parallel for schedule(dynamic, 10000) reduction(+:total_steps)
        for (uint64_t i = 1; i <= N; i++) total_steps += collatz_steps(i);

    } else if (strcmp(mode, "guided") == 0) {
        #pragma omp parallel for schedule(guided) reduction(+:total_steps)
        for (uint64_t i = 1; i <= N; i++) total_steps += collatz_steps(i);

    } else {
        fprintf(stderr, "Unknown mode '%s'\n", mode);
        return 1;
    }

    double t1 = omp_get_wtime();

    printf("Mode             = %s\n", mode);
    printf("Threads (k)      = %d\n", k);
    printf("Total steps sum  = %llu\n", (unsigned long long)total_steps);
    printf("Elapsed time (s) = %.6f\n", t1 - t0);

    return 0;
}
