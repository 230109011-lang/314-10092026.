/*
 * collatz_omp.c -- Multi-threaded OpenMP scaling (Phase 3)
 *
 * Compile:  gcc -O2 -fopenmp collatz_omp.c -o collatz_omp
 * Run:      ./collatz_omp <num_threads>
 *   e.g.    ./collatz_omp 4
 *
 * Run this once per thread count (1, 2, 4, 8, 16...) and record
 * Run1 (discard), Run2, Run3 into Table 1 yourself.
 *
 * >>> EDIT N to match your own Student-ID-derived workload <<<
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <omp.h>

#define N 19011000ULL   /* Student ID 230109011 -> last4=9011 */
#define MOD 1000000007ULL

static inline uint32_t collatz_steps(uint64_t n) {
    uint32_t steps = 0;
    while (n > 1) {
        if ((n & 1) == 0) n >>= 1;
        else n = 3 * n + 1;
        steps++;
    }
    return steps;
}

int main(int argc, char **argv) {
    int k = (argc > 1) ? atoi(argv[1]) : omp_get_max_threads();
    omp_set_num_threads(k);

    uint32_t global_max = 0;
    uint64_t global_max_i = 0;
    uint64_t checksum_total = 0;

    double t0 = omp_get_wtime();

    #pragma omp parallel
    {
        uint32_t local_max = 0;
        uint64_t local_max_i = 0;
        uint64_t local_checksum = 0;

        #pragma omp for schedule(static)
        for (uint64_t i = 1; i <= N; i++) {
            uint32_t s = collatz_steps(i);
            local_checksum = (local_checksum + s) % MOD;
            if (s > local_max) {
                local_max = s;
                local_max_i = i;
            }
        }

        #pragma omp critical
        {
            checksum_total = (checksum_total + local_checksum) % MOD;
            if (local_max > global_max) {
                global_max = local_max;
                global_max_i = local_max_i;
            }
        }
    }

    double t1 = omp_get_wtime();

    printf("Threads (k)      = %d\n", k);
    printf("N                = %llu\n", (unsigned long long)N);
    printf("Max steps        = %u (at i = %llu)\n", global_max, (unsigned long long)global_max_i);
    printf("Checksum (mod 1e9+7) = %llu\n", (unsigned long long)checksum_total);
    printf("Elapsed time (s) = %.6f\n", t1 - t0);

    return 0;
}
