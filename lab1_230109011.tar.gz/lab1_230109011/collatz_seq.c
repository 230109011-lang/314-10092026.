/*
 * collatz_seq.c -- Sequential baseline for the Amdahl Reality Gap lab
 *
 * Compile:  gcc -O2 -fopenmp collatz_seq.c -o collatz_seq
 * Run:      ./collatz_seq
 *
 * IMPORTANT: Edit N below to match YOUR unique workload:
 *   N = 10,000,000 + (last 4 digits of your Student ID * 1000)
 */

#include <stdio.h>
#include <stdint.h>
#include <omp.h>

/* >>> EDIT THIS: replace with your own computed N <<< */
#define N 19011000ULL   /* Student ID 230109011 -> last4=9011 */
#define MOD 1000000007ULL

static inline uint32_t collatz_steps(uint64_t n) {
    uint32_t steps = 0;
    while (n > 1) {
        if ((n & 1) == 0) n >>= 1;
        else n = 3 * n + 1;
        steps++;
    }
    return steps;
}

int main(void) {
    uint32_t max_steps = 0;
    uint64_t max_i = 0;
    uint64_t checksum = 0;

    double t0 = omp_get_wtime();

    for (uint64_t i = 1; i <= N; i++) {
        uint32_t s = collatz_steps(i);
        checksum = (checksum + s) % MOD;
        if (s > max_steps) {
            max_steps = s;
            max_i = i;
        }
    }

    double t1 = omp_get_wtime();

    printf("N                = %llu\n", (unsigned long long)N);
    printf("Max steps        = %u (at i = %llu)\n", max_steps, (unsigned long long)max_i);
    printf("Checksum (mod 1e9+7) = %llu\n", (unsigned long long)checksum);
    printf("Elapsed time (s) = %.6f\n", t1 - t0);

    return 0;
}
